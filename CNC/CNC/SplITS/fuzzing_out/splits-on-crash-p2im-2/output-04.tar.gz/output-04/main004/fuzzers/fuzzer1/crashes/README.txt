Command line used to find this crash:

/home/mathew/firmrebugger/fuzzers/SplITS/fuzzware/pipeline/fuzzware_pipeline/../../emulator/AFLplusplus/afl-fuzz -m none -U -t 10000 -i /home/mathew/firmrebugger/binaries/P2IM/CNC/SplITS/splits-on-crash-p2im-2/output-04/main004/base_inputs -o /home/mathew/firmrebugger/binaries/P2IM/CNC/SplITS/splits-on-crash-p2im-2/output-04/main004/fuzzers -S fuzzer1 -c 0 -- /home/mathew/.virtualenvs/fuzzware-splits/bin/python -m fuzzware_harness.harness -c /home/mathew/firmrebugger/binaries/P2IM/CNC/SplITS/splits-on-crash-p2im-2/output-04/main004/config.yml @@

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 0 B.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
an mail at <afl-users@googlegroups.com> once the issues are fixed

  https://github.com/AFLplusplus/AFLplusplus

